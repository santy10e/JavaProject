package Modelo;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.Font;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

// @author santy
public class ClaseGenerarTicket extends SuperClaseVehiculo {

    public ResultSet resultado;
    public Connection conexion;
    public Statement sentencia;
    String tipVehiculo;

    public ClaseGenerarTicket(String color, String placa, String marca, String tipoVehiculo) {
        super(color, placa, marca, tipoVehiculo);
    }

    public void generarTicket() {
        String dungeon = "src/Font/dungeon.ttf";
        String nombrePdf = super.getPlaca();
        String propietario = "";
        String placa = "";
        String horaEntrada = "";
        String horaSalida = "";
        String valorPagadoString = "EL valor Pagado Por Estacionamiento Es: ";
        Double valorPagado = 0.0;
        String valorPagadoConvert = "";
        try
        {
            final String Controlador = "com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String url_bd = "jdbc:mysql://localhost:3306/bd_ingreso_vehiculo";
            conexion = DriverManager.getConnection(url_bd, "host", "host");

            sentencia = conexion.createStatement();
            resultado = sentencia.executeQuery("SELECT * FROM vehiculos WHERE placa ='" + super.getPlaca() + "'");
            resultado.next();
            do
            {
                tipVehiculo = resultado.getString("tipoVehiculo");
                placa = "Placa del Vehículo: " + resultado.getString("placa");
                propietario = "Propietario Del Vehículo: " + resultado.getString("propietario");
                horaEntrada = "Fecha y Hora Entrada Del Vehículo: " + resultado.getString("horaEntrada");
                horaSalida = "Fecha y Hora Salida Del Vehículo: " + resultado.getString("horaSalida");
                valorPagado = resultado.getDouble("valorPagado");
                valorPagadoConvert = String.valueOf(valorPagado);
            } while (resultado.next());
            //CREAR PDF
            String destino = "src/Tickets/" + nombrePdf + ".pdf";
            Document documento = new Document();
            PdfWriter.getInstance(documento, new FileOutputStream(destino));
            //INSERTAR IMAGEN DENTRO DEL PDF
            Image imagenPrincipal = Image.getInstance("src/Imagen/imagenPdfGenTick.png");
            imagenPrincipal.scaleToFit(510, 209);
            imagenPrincipal.setAlignment(Chunk.ALIGN_CENTER);

            Paragraph titulo = new Paragraph("TICKET GENERADO DEL VEHÍCULO");
            titulo.setAlignment(Chunk.ALIGN_CENTER);
            titulo.setFont(FontFactory.getFont(dungeon, 26, Font.BOLD, BaseColor.BLUE));
            Paragraph parrafo0 = new Paragraph("****************************************************************************************************************");
            Paragraph parrafo1 = new Paragraph(propietario);
            Paragraph parrafo2 = new Paragraph(placa);
            Paragraph parrafo3 = new Paragraph(horaEntrada);
            parrafo3.setAlignment(Chunk.HEADER);
            Paragraph parrafo4 = new Paragraph(horaSalida);
            Paragraph parrafo5 = new Paragraph(valorPagadoString + valorPagadoConvert);

            documento.open();

            documento.add(imagenPrincipal);
            documento.add(parrafo0);
            documento.add(titulo);
            documento.add(parrafo1);
            documento.add(parrafo2);
            documento.add(parrafo3);
            documento.add(parrafo4);
            documento.add(parrafo5);

            documento.close();

            JOptionPane.showMessageDialog(null, "Ticket creado");

            if (new File("src/Tickets/" + nombrePdf + ".pdf").exists())
            {
                File objetoArchivo = new File("src/Tickets/" + nombrePdf + ".pdf");
                Desktop.getDesktop().open(objetoArchivo);
            } else
            {
                System.out.println("NO EXISTE EL ARCHIVO");
            }

        } catch (SQLException | ClassNotFoundException | FileNotFoundException | DocumentException ex)
        {
            Logger.getLogger(SubClaseAuto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex)
        {
            Logger.getLogger(SubClaseAuto.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
