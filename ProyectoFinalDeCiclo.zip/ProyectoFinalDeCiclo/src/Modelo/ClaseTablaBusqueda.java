package Modelo;

// @author santy
public class ClaseTablaBusqueda extends SuperClaseVehiculo {

    private String propietario;
    private String disponible;
    private String valorPagado;
    private String horaEntrada;
    private String horaSalida;

    public ClaseTablaBusqueda(String color, String placa, String marca, String tipoVehiculo) {
        super(color, placa, marca, tipoVehiculo);
    }

    public ClaseTablaBusqueda(String propietario, String disponible, String valorPagado, String color, String placa, String marca, String tipoVehiculo, String horaEntrada, String horaSalida) {
        super(color, placa, marca, tipoVehiculo);
        this.propietario = propietario;
        this.disponible = disponible;
        this.valorPagado = valorPagado;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
    }

    public String getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(String horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public String getDisponible() {
        return disponible;
    }

    public void setDisponible(String disponible) {
        this.disponible = disponible;
    }

    public String getValorPagado() {
        return valorPagado;
    }

    public void setValorPagado(String valorPagado) {
        this.valorPagado = valorPagado;
    }

    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    public void setTipoVehiculo(String tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }

}
