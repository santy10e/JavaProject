package Modelo;

import Controlador.BienvenidaFXMLController;
import Controlador.BuscarPersonaFXMLController;
import Controlador.BuscarVehiculoFXMLController;
import Controlador.HomeAdminFXMLController;
import Controlador.IngresarVehiculoFXMLController;
import Controlador.LoginAdminFXMLController;
import Controlador.PanelHomeFXMLController;
import Controlador.RegistarUserAdminFXMLController;
import Controlador.RegistrarAdminFXMLController;
import Controlador.RetirarVehiculoFXMLController;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

// @author santy
public class ClasePanel {

    public void startPanelBienvenida() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/BienvenidaFXML.fxml"));
            Parent root = loader.load();
            BienvenidaFXMLController ctrlBienvenida = loader.getController();

            Scene escenaBienvenida = new Scene(root);
            Stage stageEmpleado = new Stage();
            stageEmpleado.setScene(escenaBienvenida);
            stageEmpleado.initStyle(StageStyle.UNDECORATED);
            stageEmpleado.setResizable(false);
            stageEmpleado.showAndWait();
        } catch (IOException ex)
        {
            Logger.getLogger(BienvenidaFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelBuscarPersonal() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/BuscarPersonaFXML.fxml"));
            Parent root = loader.load();
            BuscarPersonaFXMLController ctrlBuscarPersonal = new BuscarPersonaFXMLController();

            Scene escenaBuscar = new Scene(root);
            Stage stageBuscarPersonal = new Stage();
            stageBuscarPersonal.setX(660);
            stageBuscarPersonal.setY(151);
            stageBuscarPersonal.setScene(escenaBuscar);
            stageBuscarPersonal.initStyle(StageStyle.UNDECORATED);
            stageBuscarPersonal.setResizable(false);
            stageBuscarPersonal.showAndWait();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(BuscarPersonaFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelBuscarVehiculo() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/BuscarVehiculoFXML.fxml"));
            Parent root = loader.load();
            BuscarVehiculoFXMLController ctrlBuscarVehiculo = loader.getController();

            Scene escenaBuscar = new Scene(root);
            Stage stagePanelBuscar = new Stage();
            stagePanelBuscar.setX(660);
            stagePanelBuscar.setY(151);
            stagePanelBuscar.setScene(escenaBuscar);
            stagePanelBuscar.initStyle(StageStyle.UNDECORATED);
            stagePanelBuscar.setResizable(false);
            stagePanelBuscar.showAndWait();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(BuscarVehiculoFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelHome() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/PanelHomeFXML.fxml"));
            Parent root = loader.load();
            PanelHomeFXMLController ctrlHome = loader.getController();

            Scene escenaHome = new Scene(root);
            Stage stagePanelHome = new Stage();
            stagePanelHome.setX(660);
            stagePanelHome.setY(151);
            stagePanelHome.setScene(escenaHome);
            stagePanelHome.initStyle(StageStyle.UNDECORATED);
            stagePanelHome.setResizable(false);
            stagePanelHome.showAndWait();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(PanelHomeFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelHomeAdmin() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/HomeAdminFXML.fxml"));
            Parent root = loader.load();
            HomeAdminFXMLController ctrlHomeAdmin = new HomeAdminFXMLController();

            Scene escenaHome = new Scene(root);
            Stage stagePanelHomeAdmin = new Stage();
            stagePanelHomeAdmin.setScene(escenaHome);
            stagePanelHomeAdmin.initStyle(StageStyle.UNDECORATED);
            stagePanelHomeAdmin.setResizable(false);
            stagePanelHomeAdmin.showAndWait();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(HomeAdminFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelLoginAdmin() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/LoginAdminFXML.fxml"));
            Parent root = loader.load();
            LoginAdminFXMLController ctrlAdmin = new LoginAdminFXMLController();

            Scene escenaAdmin = new Scene(root);
            Stage stageLoginAdmin = new Stage();
            stageLoginAdmin.setScene(escenaAdmin);
            stageLoginAdmin.initStyle(StageStyle.UNDECORATED);
            stageLoginAdmin.setResizable(false);
            stageLoginAdmin.showAndWait();
            stageLoginAdmin.close();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(LoginAdminFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelRegistrarAdmin() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/RegistrarAdminFXML.fxml"));
            Parent root = loader.load();
            RegistrarAdminFXMLController ctrlAdmin = new RegistrarAdminFXMLController();

            Scene escenaRegistrar = new Scene(root);
            Stage stageRegistrarAdmin = new Stage();
            stageRegistrarAdmin.setX(660);
            stageRegistrarAdmin.setY(151);
            stageRegistrarAdmin.setScene(escenaRegistrar);
            stageRegistrarAdmin.initStyle(StageStyle.UNDECORATED);
            stageRegistrarAdmin.setResizable(false);
            stageRegistrarAdmin.showAndWait();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(RegistrarAdminFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelRegistrarUsuario() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/RegistarUserAdminFXML.fxml"));
            Parent root = loader.load();
            RegistarUserAdminFXMLController ctrlUserAdmin = new RegistarUserAdminFXMLController();

            Scene escenaRegistrar = new Scene(root);
            Stage stageRegistrarUserAdmin = new Stage();
            stageRegistrarUserAdmin.setX(660);
            stageRegistrarUserAdmin.setY(151);
            stageRegistrarUserAdmin.setScene(escenaRegistrar);
            stageRegistrarUserAdmin.initStyle(StageStyle.UNDECORATED);
            stageRegistrarUserAdmin.setResizable(false);
            stageRegistrarUserAdmin.showAndWait();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(RegistarUserAdminFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void startPanelRetirarVehiculo() {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/RetirarVehiculoFXML.fxml"));
            Parent root = loader.load();
            RetirarVehiculoFXMLController ctrlRetirarVehiculo = new RetirarVehiculoFXMLController();

            Scene escenaRetirar = new Scene(root);
            Stage stagePanelRetirarVehiculo = new Stage();
            stagePanelRetirarVehiculo.setX(660);
            stagePanelRetirarVehiculo.setY(151);
            stagePanelRetirarVehiculo.setScene(escenaRetirar);
            stagePanelRetirarVehiculo.initStyle(StageStyle.UNDECORATED);
            stagePanelRetirarVehiculo.setResizable(false);
            stagePanelRetirarVehiculo.showAndWait();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(RetirarVehiculoFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
        public void startPanelIngresarVehiculo(){
                try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/IngresarVehiculoFXML.fxml"));
            Parent root = loader.load();
            IngresarVehiculoFXMLController ctrolIngresarVehiculo = new IngresarVehiculoFXMLController();

            Scene escenaIngresar = new Scene(root);
            Stage stagePanelIngresarVehiculo = new Stage();
            stagePanelIngresarVehiculo.setX(660);
            stagePanelIngresarVehiculo.setY(151);
            stagePanelIngresarVehiculo.setScene(escenaIngresar);
            stagePanelIngresarVehiculo.initStyle(StageStyle.UNDECORATED);
            stagePanelIngresarVehiculo.setResizable(false);
            stagePanelIngresarVehiculo.showAndWait();
            stagePanelIngresarVehiculo.close();

            // TODO
        } catch (IOException ex)
        {
            Logger.getLogger(IngresarVehiculoFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
