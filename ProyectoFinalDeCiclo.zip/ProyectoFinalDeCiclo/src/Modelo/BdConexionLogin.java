package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

// @author santy
public class BdConexionLogin {

    public Connection conexion;
    public Statement sentencia;
    public ResultSet resultado;

    public void ConectarBaseDeDatos() {
        try
        {
            final String Controlador = "com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String url_bd = "jdbc:mysql://localhost:3306/bd_login";
            conexion = DriverManager.getConnection(url_bd, "host", "host");
            sentencia = conexion.createStatement();
        } catch (ClassNotFoundException | SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error ", JOptionPane.ERROR_MESSAGE);
        }
    }

    public Connection getConnection() {
        return conexion;
    }

}
