
package Modelo;



 // @author santy

public class BdConexionVehiculos {
    
    
    public void conectarBaseDeDatos(){

    }

}
