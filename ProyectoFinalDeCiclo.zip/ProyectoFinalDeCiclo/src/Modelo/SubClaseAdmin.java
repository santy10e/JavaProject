
package Modelo;


 // @author santy

public class SubClaseAdmin extends SuperClasePersona {

    public SubClaseAdmin(String nombre, String apellido, String rol, String usuario, String contraseña, String correo, String edad) {
        super(nombre, apellido, rol, usuario, contraseña, correo, edad);
    }
    
    public SubClaseAdmin(String usuario, String contraseña){
        super(usuario,contraseña);
    }

}
