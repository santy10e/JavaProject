
package Modelo;


 // @author santy

public class SuperClasePersona {
    private String nombre;
    private String apellido;
    private String rol;
    private String usuario;
    private String contraseña;
    private String correo;
    private String edad;

    public SuperClasePersona(String nombre, String apellido, String rol, String usuario, String contraseña, String correo, String edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.rol = rol;
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.correo = correo;
        this.edad = edad;
    }
    
    //CONSTRUCTOR PARA EL LOGIN
    public SuperClasePersona(String usuario, String contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }
    
}
