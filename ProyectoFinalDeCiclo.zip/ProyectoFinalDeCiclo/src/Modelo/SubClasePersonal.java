
package Modelo;

 // @author santy

public class SubClasePersonal extends SuperClasePersona {
    
    
    public SubClasePersonal(String nombre, String apellido, String rol, String usuario, String contraseña, String correo, String edad) {
        super(nombre, apellido, rol, usuario, contraseña, correo, edad);
    }
    
    public SubClasePersonal(String usuario, String contraseña){
        super(usuario, contraseña);
    }



}
