package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

// @author santy
public class SubClaseCamion extends SuperClaseVehiculo implements interfaceCostoParqueo {

    public ResultSet resultado;
    public Connection conexion;
    public Statement sentencia;

    public SubClaseCamion(String color, String placa, String marca, String tipoVehiculo) {
        super(color, placa, marca, tipoVehiculo);
    }

    @Override
    public void calcularCosto() {
        Double costoPago = 0.0;
        String tipVehiculo;
        DateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar calendario = Calendar.getInstance();
        Date date = calendario.getTime();
        String fechayHora = formatoFecha.format(date);
        double valorCobrar = 0.0;
        try
        {
            Date salidaHora;
            final String Controlador = "com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String url_bd = "jdbc:mysql://localhost:3306/bd_ingreso_vehiculo";
            conexion = DriverManager.getConnection(url_bd, "host", "host");
            sentencia = conexion.createStatement();
            resultado = sentencia.executeQuery("SELECT horaEntrada, tipoVehiculo FROM `vehiculos` WHERE placa = '" + super.getPlaca() + "'");
            resultado.next();
            do
            {
                salidaHora = formatoFecha.parse(resultado.getString("horaEntrada"));
                tipVehiculo = resultado.getString("tipoVehiculo");

            } while (resultado.next());

            int costoPorMinuto = (int) (date.getTime() - salidaHora.getTime()) / 60000;
            int costoPorHora = costoPorMinuto / 60;
            //JOptionPane.showMessageDialog(null, costoPorHora);
            System.out.println(costoPorHora);//para tener control :: verificación
            System.out.println(super.getPlaca());
            if (tipVehiculo.equals("Camión"))
            {
                System.out.println(tipVehiculo);
                valorCobrar = costoPorHora * 1.00;

                JOptionPane.showMessageDialog(null, "Valor a Pagar " + valorCobrar + " Placa " + super.getPlaca());
            }
            sentencia.executeUpdate("UPDATE vehiculos SET horaSalida ='" + fechayHora + "',disponible='No Disponible' WHERE placa ='" + super.getPlaca() + "' ");

        } catch (SQLException | ParseException | ClassNotFoundException ex)
        {
            Logger.getLogger(SubClaseAuto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }



}
