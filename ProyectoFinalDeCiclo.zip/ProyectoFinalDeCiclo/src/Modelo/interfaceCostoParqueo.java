
package Modelo;


 // @author santy

public interface interfaceCostoParqueo {
    
    public void calcularCosto();
    

}
