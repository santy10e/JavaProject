/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ClasePanel;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class PanelHomeFXMLController implements Initializable {
    ClasePanel ctrlPanel = new ClasePanel();

    @FXML
    private Pane IngresarVehiculoPanelHome;
    @FXML
    private Pane retirarVehiculoPanelHome;
    @FXML
    private Pane buscarVehiculoPInicio;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // TODO
    }

    @FXML
    private void onActionIngresarVehiculoPanelHome(MouseEvent event) {
        ctrlPanel.startPanelIngresarVehiculo();
        
    }


    @FXML
    private void onClickRetirarVehiculoPanelHome(MouseEvent event) {
        ctrlPanel.startPanelRetirarVehiculo();
    }

    @FXML
    private void onClickBuscarVehiculoPanelHome(MouseEvent event) {
        ctrlPanel.startPanelBuscarVehiculo();
    }

}
