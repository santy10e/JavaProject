/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.SubClasePersonal;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class BuscarPersonaFXMLController implements Initializable {

    public ResultSet resultado;
    public Connection conexion;
    public Statement sentencia;

    @FXML
    private TableView<SubClasePersonal> tableViewPersona;
    @FXML
    private TableColumn colNombre;
    @FXML
    private TableColumn colApellido;
    @FXML
    private TableColumn colRol;
    @FXML
    private TableColumn colCorreo;
    @FXML
    private TableColumn colEdad;
    @FXML
    private TableColumn colUsuario;
    @FXML
    private TableColumn colContraseña;
    @FXML
    private Button botonBuscarPersonal;
    @FXML
    private TextField textFieldRolPersona;
    @FXML
    private ImageView imageRfrescarBuscar;

    private ObservableList<SubClasePersonal> buscarPersonal;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
          buscarPersonal = FXCollections.observableArrayList();

        this.colNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.colApellido.setCellValueFactory(new PropertyValueFactory("apellido"));
        this.colRol.setCellValueFactory(new PropertyValueFactory("rol"));
        this.colCorreo.setCellValueFactory(new PropertyValueFactory("correo"));
        this.colEdad.setCellValueFactory(new PropertyValueFactory("edad"));
        this.colUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        this.colContraseña.setCellValueFactory(new PropertyValueFactory("contraseña"));
    }

    @FXML
    private void onActionBuscarPersonal(ActionEvent event) throws SQLException {
        String nombre = "";
        String apellido = "";
        String rol = "";
        String usuario = "";
        String contraseña = "";
        String correo = "";
        String edadConvert = "";
        if (textFieldRolPersona.getText().equalsIgnoreCase("user"))
        {
            try
            {
                final String Controlador = "com.mysql.jdbc.Driver";
                Class.forName(Controlador);
                final String url_bd = "jdbc:mysql://localhost:3306/bd_login";
                conexion = DriverManager.getConnection(url_bd, "host", "host");

                sentencia = conexion.createStatement();
                resultado = sentencia.executeQuery("SELECT * FROM `login` WHERE `rol` = '" + textFieldRolPersona.getText() + "' ");
            } catch (ClassNotFoundException | SQLException ex)
            {
                Logger.getLogger(BuscarPersonaFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        if (textFieldRolPersona.getText().equalsIgnoreCase("admin"))
        {
            try
            {
                final String Controlador = "com.mysql.jdbc.Driver";
                Class.forName(Controlador);
                final String url_bd = "jdbc:mysql://localhost:3306/bd_login";
                conexion = DriverManager.getConnection(url_bd, "host", "host");

                sentencia = conexion.createStatement();
                resultado = sentencia.executeQuery("SELECT * FROM `loginadmin` WHERE `rol` = '" + textFieldRolPersona.getText() + "' ");
            } catch (ClassNotFoundException | SQLException ex)
            {
                Logger.getLogger(BuscarPersonaFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        resultado.next();
        do
        {

            nombre = resultado.getString("nombre");
            apellido = resultado.getString("apellido");
            rol = resultado.getString("rol");
            usuario = resultado.getString(""+rol+"_name");
            System.out.println(usuario);
            contraseña = resultado.getString(""+rol+"_pass");
            correo = resultado.getString("correo");
            edadConvert = resultado.getString("edad");
            
            
            SubClasePersonal tablaPersonal = new SubClasePersonal(nombre, apellido, rol, usuario, contraseña, correo, edadConvert);
            this.buscarPersonal.add(tablaPersonal);
            this.tableViewPersona.setItems(buscarPersonal);
        } while (resultado.next());

    }

    @FXML
    private void onClickRefrescarBusqueda(MouseEvent event) {
        buscarPersonal.clear();
        textFieldRolPersona.clear();
    }

}
