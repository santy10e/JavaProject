/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class RegistrarAdminFXMLController implements Initializable {
    public Connection conexion;
    public Statement sentencia;
    public ResultSet resultado;

    @FXML
    private TextField textFieldNombreAdmin;
    @FXML
    private TextField textFieldApellidoAdmin;
    @FXML
    private TextField textFieldRolAdmin;
    @FXML
    private TextField textFieldCorreoAdmin;
    @FXML
    private TextField textFieldEdadAdmin;
    @FXML
    private TextField textFieldUsuarioAdmin;
    @FXML
    private Button botonGuardarAdmin;
    @FXML
    private PasswordField passFieldContraseñaAdmin;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onActionGuardarAdmin(ActionEvent event) {
        
        String nombre =textFieldNombreAdmin.getText();
        String apellido = textFieldApellidoAdmin.getText();
        String rol = textFieldRolAdmin.getText();
        String usuario = textFieldUsuarioAdmin.getText();
        String contraseña =  passFieldContraseñaAdmin.getText();
        String correo = textFieldCorreoAdmin.getText();
        String edad = textFieldEdadAdmin.getText();
        
        try
        {
            final String Controlador = "com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String url_bd = "jdbc:mysql://localhost:3306/bd_login";
            conexion = DriverManager.getConnection(url_bd, "host", "host");
            sentencia = conexion.createStatement();
            Modelo.SubClaseAdmin ctrlClaseAdmin = new Modelo.SubClaseAdmin(nombre, apellido, rol, usuario, contraseña, correo, edad);
            String sql = "INSERT INTO `loginadmin`(`admin_name`, `admin_pass`, `nombre`, `apellido`, `rol`, `correo`, `edad`) VALUES ('" + usuario + "','" + contraseña + "','" + nombre + "','" + apellido + "','" + rol + "','" + correo + "','" + edad + "')";
            sentencia.executeUpdate(sql);

            JOptionPane.showMessageDialog(null, "El Admin Se Ha Guardado Exitosamente");
        } catch (ClassNotFoundException | SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error ", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
