/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.BdConexionLogin;
import Modelo.ClasePanel;
import Modelo.SubClasePersonal;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class FXMLLoginController implements Initializable {
    ClasePanel ctrlPanel = new ClasePanel();

    @FXML
    private TextField TextFieldUsuario;
    @FXML
    private PasswordField TextFieldContraseña;
    @FXML
    private Button botonAcceder;
    @FXML
    private ImageView BotonSalir;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void onActionAcceder(ActionEvent event) throws Exception {
        //TextFieldUsuario.setText("PRUEBA");
        try
        {
            String usuario = TextFieldUsuario.getText();
            String contraseña = TextFieldContraseña.getText();
            SubClasePersonal ctrlSubClaseEmpleado = new SubClasePersonal(usuario, contraseña);
            ctrlSubClaseEmpleado.setUsuario(usuario);
            ctrlSubClaseEmpleado.setContraseña(contraseña);
            
            //Llamando a la clase para conectar BD
            BdConexionLogin con = new BdConexionLogin();
            con.ConectarBaseDeDatos();

            // Consulta SQL 
            String SQL = "SELECT `user_name`, `user_pass` FROM `login` WHERE user_name='" + usuario + "' AND user_pass='" + contraseña + "'";

            con.resultado = con.sentencia.executeQuery(SQL);
            if (con.resultado.next())
            {
                ctrlPanel.startPanelBienvenida();
                
            } else
            {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña invalida");
            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }

    }

    @FXML
    private void onClickMouse(MouseEvent event) {
        System.exit(0);
    }
}
