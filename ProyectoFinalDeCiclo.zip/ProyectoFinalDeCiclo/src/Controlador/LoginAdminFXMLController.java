/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.BdConexionLogin;
import Modelo.ClasePanel;
import Modelo.SubClasePersonal;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class LoginAdminFXMLController implements Initializable {
    ClasePanel ctrlPanel = new ClasePanel();
    
    @FXML
    private TextField TextFieldUsuarioAdmin;
    @FXML
    private PasswordField TextFieldContraseñaAdmin;
    @FXML
    private Button botonAccederAdmin;
    @FXML
    private ImageView BotonSalirAdmin;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onActionAccederAdmin(ActionEvent event) {
                try
        {
            String usuario = TextFieldUsuarioAdmin.getText();
            String contraseña = TextFieldContraseñaAdmin.getText();
            SubClasePersonal ctrlSubClaseEmpleado = new SubClasePersonal(usuario, contraseña);
            ctrlSubClaseEmpleado.setUsuario(usuario);
            ctrlSubClaseEmpleado.setContraseña(contraseña);
            
            //Llamando a la clase para conectar BD
            BdConexionLogin con = new BdConexionLogin();
            con.ConectarBaseDeDatos();

            // Consulta SQL 
            String SQL = "SELECT `admin_name`, `admin_pass` FROM `loginadmin` WHERE admin_name='" + usuario + "' AND admin_pass='" + contraseña + "'";

            con.resultado = con.sentencia.executeQuery(SQL);
            if (con.resultado.next())
            {
               ctrlPanel.startPanelHomeAdmin();
            } else
            {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña invalida");
            }
        } catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
    }

    @FXML
    private void onClickMouseLoginAdmin(MouseEvent event) {
        ctrlPanel.startPanelLoginAdmin();
    }
    
}
