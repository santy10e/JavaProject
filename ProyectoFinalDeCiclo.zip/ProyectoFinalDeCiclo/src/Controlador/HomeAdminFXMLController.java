/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ClasePanel;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class HomeAdminFXMLController implements Initializable {
    ClasePanel ctrlPanel = new ClasePanel();

    @FXML
    private ImageView registrarADmin;
    @FXML
    private ImageView BotonSalirAdmin;
    @FXML
    private ImageView registrarADmin1;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onClickPanelRegistrar(MouseEvent event) {
        ctrlPanel.startPanelRegistrarUsuario();
    }

    @FXML
    private void onClickBotonBuscarAdmin(MouseEvent event) {
        ctrlPanel.startPanelBuscarPersonal();
    }

    @FXML
    private void onClickMouseBotonSalirHomeAdmin(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    private void onClickPanelRegistrarAdmin(MouseEvent event) {
        ctrlPanel.startPanelRegistrarAdmin();
    }
    
}
