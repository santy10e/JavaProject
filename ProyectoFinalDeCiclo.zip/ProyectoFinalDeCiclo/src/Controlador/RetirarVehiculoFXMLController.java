/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ClaseGenerarTicket;
import Modelo.SubClaseAuto;
import Modelo.SubClaseCamion;
import Modelo.SubClaseMotocicleta;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class RetirarVehiculoFXMLController implements Initializable {

    public Connection conexion;
    public Statement sentencia;
    public ResultSet resultado;

    @FXML
    private TextField textFieldPlaca;
    @FXML
    private Button botonRetirarVehiculo;
    @FXML
    private Button botonImprimirTicket;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // TODO
    }

    @FXML
    private void onActionRetirarVehiculo(ActionEvent event) throws ClassNotFoundException {
        SubClaseAuto ctrlSubClaseAuto = new SubClaseAuto(null, textFieldPlaca.getText(), null, null);
        SubClaseMotocicleta ctrlSubClaseMotocicleta = new SubClaseMotocicleta(null, textFieldPlaca.getText(), null, null);
        SubClaseCamion ctrlSubClaseCamion = new SubClaseCamion(null, textFieldPlaca.getText(), null, null);
        ctrlSubClaseAuto.calcularCosto();
        ctrlSubClaseMotocicleta.calcularCosto();
        ctrlSubClaseCamion.calcularCosto();
//        try
//        {
//            final String Controlador = "com.mysql.jdbc.Driver";
//            Class.forName(Controlador);
//            final String url_bd = "jdbc:mysql://localhost:3306/bd_ingreso_vehiculo";
//            conexion = DriverManager.getConnection(url_bd, "host", "host");
//            sentencia = conexion.createStatement();
//            //String sql = "SELECT 'propietario','placa','tipoVehiculo','horaEntrada' FROM placa = "+textFieldPlaca.getText()+"";
//            String sql = "SELECT `propietario`, `placa`, `tipoVehiculo`, `horaEntrada` FROM `vehiculos` WHERE placa = "+textFieldPlaca.getText()+"";
//            sentencia.executeQuery(sql);
//             JOptionPane.showMessageDialog(null, sql);
//        } catch (SQLException ex)
//        {
//            Logger.getLogger(RetirarVehiculoFXMLController.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }

    @FXML
    private void onActionImprimirTicket(ActionEvent event) {
        ClaseGenerarTicket  ctrlGenerarTicket = new ClaseGenerarTicket(null, textFieldPlaca.getText(), null, null);
        ctrlGenerarTicket.generarTicket();
    }

}
