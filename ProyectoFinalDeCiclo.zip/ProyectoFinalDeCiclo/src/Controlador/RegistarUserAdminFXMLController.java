/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.SubClasePersonal;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class RegistarUserAdminFXMLController implements Initializable {

    public Connection conexion;
    public Statement sentencia;
    public ResultSet resultado;

    @FXML
    private TextField textFieldNombreUser;
    @FXML
    private TextField textFieldApellidoUser;
    @FXML
    private TextField textFieldRolUser;
    @FXML
    private TextField textFieldCorreoUser;
    @FXML
    private TextField textFieldEdadUser;
    @FXML
    private TextField textFieldUsuarioUser;
    @FXML
    private Button botonGuardarUsuario;
    @FXML
    private PasswordField passFieldContraseñaUser;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void onActionGuardarUsuario(ActionEvent event) {
        String nombre =textFieldNombreUser.getText();
        String apellido = textFieldApellidoUser.getText();
        String rol = textFieldRolUser.getText();
        String usuario = textFieldUsuarioUser.getText();
        String contraseña =  passFieldContraseñaUser.getText();
        String correo = textFieldCorreoUser.getText();
        String edad = textFieldEdadUser.getText();
        
        try
        {
            final String Controlador = "com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String url_bd = "jdbc:mysql://localhost:3306/bd_login";
            conexion = DriverManager.getConnection(url_bd, "host", "host");
            sentencia = conexion.createStatement();

            SubClasePersonal ctrlClasePersonal = new SubClasePersonal(nombre, apellido,rol ,usuario ,contraseña,correo ,edad );
            String sql = "INSERT INTO `login`(`user_name`, `user_pass`, `nombre`, `apellido`, `rol`, `correo`, `edad`) VALUES ('" + usuario + "','" + contraseña + "','" + nombre + "','" + apellido + "','" + rol + "','" + correo + "','" + edad + "')";
            sentencia.executeUpdate(sql);

            JOptionPane.showMessageDialog(null, "El Usuario Se Ha Guardado Exitosamente");
        } catch (ClassNotFoundException | SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error ", JOptionPane.ERROR_MESSAGE);
        }

    }

}
