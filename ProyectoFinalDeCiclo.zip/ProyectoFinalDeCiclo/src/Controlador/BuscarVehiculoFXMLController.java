/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ClaseTablaBusqueda;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class BuscarVehiculoFXMLController implements Initializable {

    public ResultSet resultado;
    public Connection conexion;
    public Statement sentencia;
    String tipVehiculo;

    @FXML
    private Button botonBuscarVehiculos;
    @FXML
    private TextField textFieldPlacaBuscarVehiculo;
    @FXML
    private TextField textFieldNombrePropietario;
    @FXML
    private DatePicker DatePickerFecha;
    @FXML
    private TableView<ClaseTablaBusqueda> tablaBuscarVehiculo;
    @FXML
    private TableColumn colPropietario;
    @FXML
    private TableColumn colPlaca;
    @FXML
    private TableColumn colTipoVehiculo;
    @FXML
    private TableColumn colHoraEntrada;
    @FXML
    private TableColumn colHoraSalida;
    @FXML
    private TableColumn colColor;
    @FXML
    private TableColumn colMarca;
    @FXML
    private TableColumn colDisponible;
    @FXML
    private TableColumn colValorPagado;

    private ObservableList<ClaseTablaBusqueda> buscarVehiculo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        buscarVehiculo = FXCollections.observableArrayList();

        this.colPlaca.setCellValueFactory(new PropertyValueFactory("placa"));
        this.colPropietario.setCellValueFactory(new PropertyValueFactory("propietario"));
        this.colDisponible.setCellValueFactory(new PropertyValueFactory("disponible"));
        this.colValorPagado.setCellValueFactory(new PropertyValueFactory("valorPagado"));
        this.colHoraEntrada.setCellValueFactory(new PropertyValueFactory("horaEntrada"));
        this.colHoraSalida.setCellValueFactory(new PropertyValueFactory("horaSalida"));
        this.colColor.setCellValueFactory(new PropertyValueFactory("color"));
        this.colMarca.setCellValueFactory(new PropertyValueFactory("marca"));
        this.colTipoVehiculo.setCellValueFactory(new PropertyValueFactory("tipoVehiculo"));
    }

    String consulta = "";
    String tipoVehiculo = "";
    String estado = "";
    String fecha = "";

    @FXML
    private void onActionBuscarVehiculos(ActionEvent event) {
        String horaEntrada = "";
        String placa = "";
        String propietario = "";
        String disponible = "";
        String horaSalida = "";
        Double valorPagado = 0.0;
        String valorPagaconvert = "";
        String color = "";
        String marca = "";
        String tipoVehiculo = "";
        if (DatePickerFecha.getValue() != null)
        {
//            DateFormat fechaFormateada = new SimpleDateFormat("yyyy-MM-dd");
            LocalDate date = DatePickerFecha.getValue();
            fecha = date.toString();
            System.out.println(date.toString());

        }
        try
        {
            final String Controlador = "com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String url_bd = "jdbc:mysql://localhost:3306/bd_ingreso_vehiculo";
            conexion = DriverManager.getConnection(url_bd, "host", "host");

            sentencia = conexion.createStatement();
            resultado = sentencia.executeQuery("SELECT * FROM `vehiculos` WHERE `horaEntrada` LIKE '%" + fecha + "%' AND `placa` LIKE '%" + textFieldPlacaBuscarVehiculo.getText() + "%'  AND `propietario` LIKE '%" + textFieldNombrePropietario.getText() + "%' ");
            resultado.next();
            do
            {

                horaEntrada = resultado.getString("horaEntrada");
                placa = resultado.getString("placa");
                propietario = resultado.getString("propietario");
                disponible = resultado.getString("disponible");
                horaSalida = resultado.getString("horaSalida");
                valorPagado = resultado.getDouble("valorPagado");
                valorPagaconvert = String.valueOf(valorPagado);
                color = resultado.getString("color");
                marca = resultado.getString("marca");
                tipoVehiculo = resultado.getString("tipoVehiculo");

                ClaseTablaBusqueda tablaBuscar = new ClaseTablaBusqueda(propietario, disponible, valorPagaconvert, color, placa, marca, tipoVehiculo, horaEntrada, horaSalida);
                this.buscarVehiculo.add(tablaBuscar);
                this.tablaBuscarVehiculo.setItems(buscarVehiculo);
            } while (resultado.next());

            System.out.println(horaEntrada);

//            while(resultado.next()){
//                buscarVehiculo.add(new ClaseTablaBusqueda(propietario, disponible, valorPagaconvert, color, placa, marca, tipoVehiculo, horaEntrada, horaSalida));
//                tablaBuscarVehiculo.setItems(buscarVehiculo);
//            }
        } catch (SQLException | ClassNotFoundException ex)
        {
            Logger.getLogger(BuscarVehiculoFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void onClickRefrescarBusqueda(MouseEvent event) {
        buscarVehiculo.clear();
        textFieldPlacaBuscarVehiculo.clear();
        textFieldNombrePropietario.clear();
    }

}
