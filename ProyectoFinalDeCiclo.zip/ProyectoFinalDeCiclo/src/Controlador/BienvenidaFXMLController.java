/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.BdConexionLogin;
import Modelo.ClasePanel;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class BienvenidaFXMLController implements Initializable {
    ClasePanel ctrlPanel = new ClasePanel();

    @FXML
    private ImageView botonSalirPB;
    @FXML
    private Label lblBienvenido;
    @FXML
    private ImageView BotonBuscarVehiculoPBienvenida;
    @FXML
    private ImageView botonSetup;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        BdConexionLogin ctrlClaseBdConexionLogin = new BdConexionLogin();
        ctrlClaseBdConexionLogin.ConectarBaseDeDatos();
        
    }

    @FXML
    private void onClickBotonSalir(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    private void onClickPanelHome(MouseEvent event) {
        ctrlPanel.startPanelHome();
    }

    @FXML
    private void onClickBotonIngresar(MouseEvent event) {
        
        ctrlPanel.startPanelIngresarVehiculo();
    }

    @FXML
    private void onClickBotonRetirar(MouseEvent event) {
        ctrlPanel.startPanelRetirarVehiculo();
    }

    @FXML
    private void onClickBuscarVehiculoPbienvenida(MouseEvent event) {
        ctrlPanel.startPanelBuscarVehiculo();
    }

    @FXML
    private void onClickBotonSetup(MouseEvent event) {
        ctrlPanel.startPanelLoginAdmin();
    }



}
