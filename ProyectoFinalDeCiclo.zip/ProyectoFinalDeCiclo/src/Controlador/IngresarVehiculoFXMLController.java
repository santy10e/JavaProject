/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ClasePanel;
import Modelo.SubClaseAuto;
import Modelo.SubClaseCamion;
import Modelo.SubClaseMotocicleta;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author santy
 */
public class IngresarVehiculoFXMLController implements Initializable {

    ClasePanel ctrlPanel = new ClasePanel();

    public Connection conexion;
    public Statement sentencia;
    public ResultSet resultado;

    @FXML
    private Button botonGuardarIngresarVehiculo;
    @FXML
    private RadioButton brMotocicleta;
    @FXML
    private RadioButton brAuto;
    @FXML
    private RadioButton brCamion;
    @FXML
    private TextField textFieldPlaca;
    @FXML
    private TextField textFieldNombPropie;
    @FXML
    private TextField textFieldColor;
    @FXML
    private TextField textFieldMarca;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    String fechaHora = "";
    String claseVehiculo = "";
//    String color="";
//    String placa="";
//    String marca;

    @FXML
    private void onActionGuardarIngresoVehiculo(ActionEvent event) throws SQLException {
        try
        {
            final String Controlador = "com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String url_bd = "jdbc:mysql://localhost:3306/bd_ingreso_vehiculo";
            conexion = DriverManager.getConnection(url_bd, "host", "host");
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar cal = Calendar.getInstance();
            Date date = cal.getTime();
            fechaHora = dateFormat.format(date);
            sentencia = conexion.createStatement();
            if (brAuto.isSelected())
            {
                claseVehiculo = "Auto";
                SubClaseAuto ctrlSubClaseAuto = new SubClaseAuto(textFieldColor.getText(), textFieldPlaca.getText(), textFieldMarca.getText(), claseVehiculo);
                String sql = "INSERT INTO `vehiculos`(`propietario`, `placa`, `tipoVehiculo`, `horaEntrada`, `color`, `marca`, `disponible` ) VALUES ('" + textFieldNombPropie.getText() + "','" + ctrlSubClaseAuto.getPlaca() + "','" + claseVehiculo + "','" + fechaHora + "','" + ctrlSubClaseAuto.getColor() + "','" + ctrlSubClaseAuto.getMarca() + "', 'Disponible')";
                sentencia.executeUpdate(sql);
            }
            if (brMotocicleta.isSelected())
            {
                claseVehiculo = "Motocicleta";
                SubClaseMotocicleta ctrlSubClaseMotocicleta = new SubClaseMotocicleta(textFieldColor.getText(), textFieldPlaca.getText(), textFieldMarca.getText(), claseVehiculo);
                String sql = "INSERT INTO `vehiculos`(`propietario`, `placa`, `tipoVehiculo`, `horaEntrada`, `color`, `marca`, `disponible` ) VALUES ('" + textFieldNombPropie.getText() + "','" + ctrlSubClaseMotocicleta.getPlaca() + "','" + claseVehiculo + "','" + fechaHora + "','" + ctrlSubClaseMotocicleta.getColor() + "','" + ctrlSubClaseMotocicleta.getMarca() + "', 'Disponible')";
                sentencia.executeUpdate(sql);
            }
            if (brCamion.isSelected())
            {
                claseVehiculo = "Camión";
                SubClaseCamion ctrlSubClaseCamion = new SubClaseCamion(textFieldColor.getText(), textFieldPlaca.getText(), textFieldMarca.getText(), claseVehiculo);
                String sql = "INSERT INTO `vehiculos`(`propietario`, `placa`, `tipoVehiculo`, `horaEntrada`, `color`, `marca`, `disponible` ) VALUES ('" + textFieldNombPropie.getText() + "','" + ctrlSubClaseCamion.getPlaca() + "','" + claseVehiculo + "','" + fechaHora + "','" + ctrlSubClaseCamion.getColor() + "','" + ctrlSubClaseCamion.getMarca() + "', 'Disponible')";
                sentencia.executeUpdate(sql);
            }

            JOptionPane.showMessageDialog(null, "El vehiculo se ha guardado exitosamente");
        } catch (ClassNotFoundException | SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error ", JOptionPane.ERROR_MESSAGE);
        }
    }

}
